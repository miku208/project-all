import type {
  GetCatalogOptions,
  ProductCreate,
  ProductUpdate,
  SocketConfig,
  WAMediaUpload,
} from "../Types/index.js";
import type {
  UpdateBusinessProfileProps,
  UpdateBussinesProfileProps,
} from "../Types/Bussines.js";
import { type BinaryNode } from "../WABinary/index.js";
export declare const makeBusinessSocket: (config: SocketConfig) => {
  logger: import("../Utils/logger.js").ILogger;
  getOrderDetails: (
    orderId: string,
    tokenBase64: string,
  ) => Promise<import("../index.js").OrderDetails>;
  getCatalog: ({ jid, limit, cursor }: GetCatalogOptions) => Promise<{
    products: import("../index.js").Product[];
    nextPageCursor: string | undefined;
  }>;
  getCollections: (
    jid?: string,
    limit?: number,
  ) => Promise<{
    collections: import("../index.js").CatalogCollection[];
  }>;
  productCreate: (
    create: ProductCreate,
  ) => Promise<import("../index.js").Product>;
  productDelete: (productIds: string[]) => Promise<{
    deleted: number;
  }>;
  productUpdate: (
    productId: string,
    update: ProductUpdate,
  ) => Promise<import("../index.js").Product>;
  updateBusinessProfile: (args: UpdateBusinessProfileProps) => Promise<any>;
  updateBussinesProfile: (args: UpdateBussinesProfileProps) => Promise<any>;
  updateCoverPhoto: (photo: WAMediaUpload) => Promise<number>;
  removeCoverPhoto: (id: string) => Promise<any>;
  sendMessageAck: (node: BinaryNode, errorCode?: number) => Promise<void>;
  sendRetryRequest: (
    node: BinaryNode,
    forceIncludeKeys?: boolean,
  ) => Promise<void>;
  rejectCall: (callId: string, callFrom: string) => Promise<void>;
  fetchMessageHistory: (
    count: number,
    oldestMsgKey: import("../index.js").WAMessageKey,
    oldestMsgTimestamp: number | import("long").default,
  ) => Promise<string>;
  requestPlaceholderResend: (
    messageKey: import("../index.js").WAMessageKey,
    msgData?: Partial<import("../index.js").WAMessage>,
  ) => Promise<string | undefined>;
  messageRetryManager: import("../index.js").MessageRetryManager | null;
  getPrivacyTokens: (jids: string[]) => Promise<any>;
  assertSessions: (jids: string[], force?: boolean) => Promise<boolean>;
  relayMessage: (
    jid: string,
    message: import("../index.js").proto.IMessage,
    {
      messageId: msgId,
      participant,
      additionalAttributes,
      additionalNodes,
      useUserDevicesCache,
      useCachedGroupMetadata,
      statusJidList,
    }: import("../index.js").MessageRelayOptions,
  ) => Promise<string>;
  sendReceipt: (
    jid: string,
    participant: string | undefined,
    messageIds: string[],
    type: import("../index.js").MessageReceiptType,
  ) => Promise<void>;
  sendReceipts: (
    keys: import("../index.js").WAMessageKey[],
    type: import("../index.js").MessageReceiptType,
  ) => Promise<void>;
  ourin: import("./dugong.js").Dugong;
  readMessages: (keys: import("../index.js").WAMessageKey[]) => Promise<void>;
  refreshMediaConn: (
    forceGet?: boolean,
  ) => Promise<import("../index.js").MediaConnInfo>;
  waUploadToServer: import("../index.js").WAMediaUploadFunction;
  fetchPrivacySettings: (force?: boolean) => Promise<{
    [_: string]: string;
  }>;
  sendPeerDataOperationMessage: (
    pdoMessage: import("../index.js").proto.Message.IPeerDataOperationRequestMessage,
  ) => Promise<string>;
  createParticipantNodes: (
    recipientJids: string[],
    message: import("../index.js").proto.IMessage,
    extraAttrs?: BinaryNode["attrs"],
    dsmMessage?: import("../index.js").proto.IMessage,
  ) => Promise<{
    nodes: BinaryNode[];
    shouldIncludeDeviceIdentity: boolean;
  }>;
  getUSyncDevices: (
    jids: string[],
    useCache: boolean,
    ignoreZeroDevices: boolean,
  ) => Promise<
    (import("../index.js").JidWithDevice & {
      jid: string;
    })[]
  >;
  updateMemberLabel: (jid: string, memberLabel: string) => Promise<string>;
  updateMediaMessage: (
    message: import("../index.js").WAMessage,
  ) => Promise<import("../index.js").WAMessage>;
  sendStatusMention: (
    content: any,
    jids?: string[],
  ) => Promise<import("../index.js").WAMessage>;
  sendTable: (
    jid: string,
    title: string,
    headers: string[],
    rows: string[][],
    quoted?: any,
    options?: import("../index.js").RichMessageOptions,
  ) => Promise<{
    message: any;
    messageId: string;
  }>;
  sendList: (
    jid: string,
    title: string,
    items: (string | string[])[],
    quoted?: any,
    options?: import("../index.js").RichMessageOptions,
  ) => Promise<{
    message: any;
    messageId: string;
  }>;
  sendCodeBlock: (
    jid: string,
    code: string,
    quoted?: any,
    options?: import("../index.js").CodeBlockOptions,
  ) => Promise<{
    message: any;
    messageId: string;
  }>;
  sendLatex: (
    jid: string,
    quoted: any,
    options: import("../index.js").LatexOptions,
  ) => Promise<{
    message: any;
    messageId: string;
  }>;
  sendLatexImage: (
    jid: string,
    quoted: any,
    options: import("../index.js").LatexImageOptions,
    renderLatexToPng: import("../index.js").LatexRenderFn,
    uploadFn: import("../index.js").MediaUploadFn,
  ) => Promise<{
    message: any;
    messageId: string;
  }>;
  sendLatexInlineImage: (
    jid: string,
    quoted: any,
    options: import("../index.js").LatexImageOptions,
    renderLatexToPng: import("../index.js").LatexRenderFn,
    uploadFn: import("../index.js").MediaUploadFn,
  ) => Promise<{
    message: any;
    messageId: string;
  }>;
  captureUnifiedResponse: (
    msg: import("../index.js").proto.IMessage,
  ) => import("../index.js").CapturedUnifiedResponse | null;
  sendUnifiedResponse: (
    jid: string,
    quoted: any,
    captured: import("../index.js").CapturedUnifiedResponse,
  ) => Promise<{
    message: any;
    messageId: string;
  }>;
  sendRichMessage: (
    jid: string,
    submessages: import("../index.js").proto.IAIRichResponseSubMessage[],
    quoted?: any,
    options?: {},
  ) => Promise<{
    message: any;
    messageId: string;
  }>;
  sendMessage: (
    jid: string,
    content: import("../index.js").AnyMessageContent,
    options?: import("../index.js").MiscMessageGenerationOptions,
  ) => Promise<any>;
  newsletterFetchAllSubscribe: () => Promise<unknown>;
  newsletterMultipleFollow: (jids: string) => Promise<void>;
  newsletterAction: (jid: string, type: string) => Promise<void>;
  cekIDSaluran: (url: string) => Promise<{
    id: any;
    state: any;
    creation_time: number;
    name: any;
    description: any;
    invite: any;
    picture: string;
    preview: string;
    subscribers: number;
    verification: any;
    viewer_metadata: any;
  }>;
  newsletterCreate: (
    name: string,
    description?: string,
  ) => Promise<import("../index.js").NewsletterMetadata>;
  newsletterUpdate: (
    jid: string,
    updates: import("../index.js").NewsletterUpdate,
  ) => Promise<unknown>;
  newsletterSubscribers: (jid: string) => Promise<{
    subscribers: number;
  }>;
  newsletterMetadata: (
    type: "invite" | "jid",
    key: string,
  ) => Promise<import("../index.js").NewsletterMetadata | null>;
  newsletterFollow: (jid: string) => Promise<unknown>;
  newsletterUnfollow: (jid: string) => Promise<unknown>;
  newsletterMute: (jid: string) => Promise<unknown>;
  newsletterUnmute: (jid: string) => Promise<unknown>;
  newsletterUpdateName: (jid: string, name: string) => Promise<unknown>;
  newsletterUpdateDescription: (
    jid: string,
    description: string,
  ) => Promise<unknown>;
  newsletterUpdatePicture: (
    jid: string,
    content: WAMediaUpload,
  ) => Promise<unknown>;
  newsletterRemovePicture: (jid: string) => Promise<unknown>;
  newsletterReactMessage: (
    jid: string,
    serverId: string,
    reaction?: string,
  ) => Promise<void>;
  newsletterFetchMessages: (
    jid: string,
    count: number,
    since: number,
    after: number,
  ) => Promise<any>;
  subscribeNewsletterUpdates: (jid: string) => Promise<{
    duration: string;
  } | null>;
  newsletterAdminCount: (jid: string) => Promise<number>;
  newsletterChangeOwner: (jid: string, newOwnerJid: string) => Promise<void>;
  newsletterDemote: (jid: string, userJid: string) => Promise<void>;
  newsletterDelete: (jid: string) => Promise<void>;
  groupMetadata: (jid: string) => Promise<import("../index.js").GroupMetadata>;
  groupCreate: (
    subject: string,
    participants: string[],
  ) => Promise<import("../index.js").GroupMetadata>;
  groupLeave: (id: string) => Promise<void>;
  groupUpdateSubject: (jid: string, subject: string) => Promise<void>;
  groupRequestParticipantsList: (jid: string) => Promise<
    {
      [key: string]: string;
    }[]
  >;
  groupRequestParticipantsUpdate: (
    jid: string,
    participants: string[],
    action: "approve" | "reject",
  ) => Promise<
    {
      status: string;
      jid: string | undefined;
    }[]
  >;
  groupParticipantsUpdate: (
    jid: string,
    participants: string[],
    action: import("../index.js").ParticipantAction,
  ) => Promise<
    {
      status: string;
      jid: string | undefined;
      content: BinaryNode;
    }[]
  >;
  groupUpdateDescription: (jid: string, description?: string) => Promise<void>;
  groupInviteCode: (jid: string) => Promise<string | undefined>;
  groupRevokeInvite: (jid: string) => Promise<string | undefined>;
  groupAcceptInvite: (code: string) => Promise<string | undefined>;
  groupRevokeInviteV4: (
    groupJid: string,
    invitedJid: string,
  ) => Promise<boolean>;
  groupAcceptInviteV4: (
    key: string | import("../index.js").WAMessageKey,
    inviteMessage: import("../index.js").proto.Message.IGroupInviteMessage,
  ) => Promise<any>;
  groupGetInviteInfo: (
    code: string,
  ) => Promise<import("../index.js").GroupMetadata>;
  groupToggleEphemeral: (
    jid: string,
    ephemeralExpiration: number,
  ) => Promise<void>;
  groupSettingUpdate: (
    jid: string,
    setting: "announcement" | "not_announcement" | "locked" | "unlocked",
  ) => Promise<void>;
  groupMemberAddMode: (
    jid: string,
    mode: "admin_add" | "all_member_add",
  ) => Promise<void>;
  groupJoinApprovalMode: (jid: string, mode: "on" | "off") => Promise<void>;
  groupFetchAllParticipating: () => Promise<{
    [_: string]: import("../index.js").GroupMetadata;
  }>;
  createCallLink: (
    type: "audio" | "video",
    event?: {
      startTime: number;
    },
    timeoutMs?: number,
  ) => Promise<string | undefined>;
  getBotListV2: () => Promise<import("../index.js").BotListInfo[]>;
  messageMutex: {
    mutex<T>(code: () => Promise<T> | T): Promise<T>;
  };
  receiptMutex: {
    mutex<T>(code: () => Promise<T> | T): Promise<T>;
  };
  appStatePatchMutex: {
    mutex<T>(code: () => Promise<T> | T): Promise<T>;
  };
  notificationMutex: {
    mutex<T>(code: () => Promise<T> | T): Promise<T>;
  };
  upsertMessage: (
    msg: import("../index.js").WAMessage,
    type: import("../index.js").MessageUpsertType,
  ) => Promise<void>;
  appPatch: (patchCreate: import("../index.js").WAPatchCreate) => Promise<void>;
  sendPresenceUpdate: (
    type: import("../index.js").WAPresence,
    toJid?: string,
  ) => Promise<void>;
  presenceSubscribe: (toJid: string) => Promise<void>;
  profilePictureUrl: (
    jid: string,
    type?: "preview" | "image",
    timeoutMs?: number,
  ) => Promise<string | undefined>;
  fetchBlocklist: () => Promise<(string | undefined)[]>;
  fetchStatus: (
    ...jids: string[]
  ) => Promise<import("../index.js").USyncQueryResultList[] | undefined>;
  fetchDisappearingDuration: (
    ...jids: string[]
  ) => Promise<import("../index.js").USyncQueryResultList[] | undefined>;
  updateProfilePicture: (
    jid: string,
    content: WAMediaUpload,
    dimensions?: {
      width: number;
      height: number;
    },
  ) => Promise<void>;
  removeProfilePicture: (jid: string) => Promise<void>;
  updateProfileStatus: (status: string) => Promise<void>;
  updateProfileName: (name: string) => Promise<void>;
  updateBlockStatus: (
    jid: string,
    action: "block" | "unblock",
  ) => Promise<void>;
  updateDisableLinkPreviewsPrivacy: (
    isPreviewsDisabled: boolean,
  ) => Promise<void>;
  updateCallPrivacy: (
    value: import("../index.js").WAPrivacyCallValue,
  ) => Promise<void>;
  updateMessagesPrivacy: (
    value: import("../index.js").WAPrivacyMessagesValue,
  ) => Promise<void>;
  updateLastSeenPrivacy: (
    value: import("../index.js").WAPrivacyValue,
  ) => Promise<void>;
  updateOnlinePrivacy: (
    value: import("../index.js").WAPrivacyOnlineValue,
  ) => Promise<void>;
  updateProfilePicturePrivacy: (
    value: import("../index.js").WAPrivacyValue,
  ) => Promise<void>;
  updateStatusPrivacy: (
    value: import("../index.js").WAPrivacyValue,
  ) => Promise<void>;
  updateReadReceiptsPrivacy: (
    value: import("../index.js").WAReadReceiptsValue,
  ) => Promise<void>;
  updateGroupsAddPrivacy: (
    value: import("../index.js").WAPrivacyGroupAddValue,
  ) => Promise<void>;
  updateDefaultDisappearingMode: (duration: number) => Promise<void>;
  getBusinessProfile: (
    jid: string,
  ) => Promise<import("../index.js").WABusinessProfile | void>;
  resyncAppState: (
    collections: readonly (
      | "critical_unblock_low"
      | "regular_high"
      | "regular_low"
      | "critical_block"
      | "regular"
    )[],
    isInitialSync: boolean,
  ) => Promise<void>;
  chatModify: (
    mod: import("../index.js").ChatModification,
    jid: string,
  ) => Promise<void>;
  cleanDirtyBits: (
    type: "account_sync" | "groups",
    fromTimestamp?: number | string,
  ) => Promise<void>;
  addOrEditContact: (
    jid: string,
    contact: import("../index.js").proto.SyncActionValue.IContactAction,
  ) => Promise<void>;
  removeContact: (jid: string) => Promise<void>;
  addLabel: (
    jid: string,
    labels: import("../Types/Label.js").LabelActionBody,
  ) => Promise<void>;
  addChatLabel: (jid: string, labelId: string) => Promise<void>;
  removeChatLabel: (jid: string, labelId: string) => Promise<void>;
  addMessageLabel: (
    jid: string,
    messageId: string,
    labelId: string,
  ) => Promise<void>;
  removeMessageLabel: (
    jid: string,
    messageId: string,
    labelId: string,
  ) => Promise<void>;
  star: (
    jid: string,
    messages: {
      id: string;
      fromMe?: boolean;
    }[],
    star: boolean,
  ) => Promise<void>;
  addOrEditQuickReply: (
    quickReply: import("../Types/Bussines.js").QuickReplyAction,
  ) => Promise<void>;
  removeQuickReply: (timestamp: string) => Promise<void>;
  type: "md";
  ws: import("./Client/index.js").WebSocketClient;
  ev: import("../index.js").BaileysEventEmitter & {
    process(
      handler: (
        events: Partial<import("../index.js").BaileysEventMap>,
      ) => void | Promise<void>,
    ): () => void;
    buffer(): void;
    createBufferedFunction<A extends any[], T>(
      work: (...args: A) => Promise<T>,
    ): (...args: A) => Promise<T>;
    flush(): boolean;
    isBuffering(): boolean;
  };
  authState: {
    creds: import("../index.js").AuthenticationCreds;
    keys: import("../index.js").SignalKeyStoreWithTransaction;
  };
  signalRepository: import("../index.js").SignalRepositoryWithLIDStore;
  user: import("../index.js").Contact | undefined;
  generateMessageTag: () => string;
  query: (node: BinaryNode, timeoutMs?: number) => Promise<any>;
  waitForMessage: <T>(
    msgId: string,
    timeoutMs?: number | undefined,
  ) => Promise<T | undefined>;
  waitForSocketOpen: () => Promise<void>;
  sendRawMessage: (data: Uint8Array | Buffer) => Promise<void>;
  sendNode: (frame: BinaryNode) => Promise<void>;
  logout: (msg?: string) => Promise<void>;
  end: (error: Error | undefined) => Promise<void>;
  onUnexpectedError: (
    err: Error | import("@hapi/boom").Boom,
    msg: string,
  ) => void;
  uploadPreKeys: (count?: number, retryCount?: number) => Promise<void>;
  uploadPreKeysToServerIfRequired: () => Promise<void>;
  digestKeyBundle: () => Promise<void>;
  rotateSignedPreKey: () => Promise<void>;
  requestPairingCode: (
    phoneNumber: string,
    customPairingCode?: string,
  ) => Promise<string>;
  updateServerTimeOffset: ({ attrs }: BinaryNode) => void;
  sendUnifiedSession: () => Promise<void>;
  wamBuffer: import("../index.js").BinaryInfo;
  waitForConnectionUpdate: (
    check: (
      u: Partial<import("../index.js").ConnectionState>,
    ) => Promise<boolean | undefined>,
    timeoutMs?: number,
  ) => Promise<void>;
  sendWAMBuffer: (wamBuffer: Buffer) => Promise<any>;
  executeUSyncQuery: (
    usyncQuery: import("../index.js").USyncQuery,
  ) => Promise<import("../index.js").USyncQueryResult | undefined>;
  onWhatsApp: (...phoneNumber: string[]) => Promise<
    | {
        jid: string;
        exists: boolean;
      }[]
    | undefined
  >;
};
//# sourceMappingURL=business.d.ts.map
